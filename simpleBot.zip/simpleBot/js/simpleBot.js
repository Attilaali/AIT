// simpleBot.js

(function(ext) {
    var device = null;
    var _rxBuf = [];

    // Sensor states:
    var ports = {
        jack_1: 1,
        jack_2: 2,
        jack_3: 3,
        jack_4: 4,
        jack_5: 5,
        jack_6: 6,
        jack_7: 7,
        jack_8: 8,
		jack1_Lpin:11,
		jack1_Rpin:12,
		jack2_Lpin:9,
		jack2_Rpin:10,
		jack3_Lpin:16,
		jack3_Rpin:17,
		jack4_Lpin:14,
		jack4_Rpin:15,
		_jack1_:11,
		_jack2_:9,
		_jack3_:16,
		_jack4_:14,
		_A_:9,
		_B_:10,
		A_and_B:255,
		'led on board':7,
		'on_board':6
    };
	var switchStatus = {
		On:1,
		Off:0
	};
	var shutterStatus = {
		Press:1,
		Release:0,
		'Focus On':3,
		'Focus Off':2
	};
	var button_keys = {
		"key1":1,
		"key2":2,
		"key3":3,
		"key4":4
	};
	var tones ={"B0":31,"C1":33,"D1":37,"E1":41,"F1":44,"G1":49,"A1":55,"B1":62,
			"C2":65,"D2":73,"E2":82,"F2":87,"G2":98,"A2":110,"B2":123,
			"C3":131,"D3":147,"E3":165,"F3":175,"G3":196,"A3":220,"B3":247,
			"C4":262,"D4":294,"E4":330,"F4":349,"G4":392,"A4":440,"B4":494,
			"C5":523,"D5":587,"E5":659,"F5":698,"G5":784,"A5":880,"B5":988,
			"C6":1047,"D6":1175,"E6":1319,"F6":1397,"G6":1568,"A6":1760,"B6":1976,
			"C7":2093,"D7":2349,"E7":2637,"F7":2794,"G7":3136,"A7":3520,"B7":3951,
	"C8":4186,"D8":4699};
	var beats = {"Half":500,"Quarter":250,"Eighth":125,"Whole":1000,"Double":2000,"Zero":0};
	var ircodes = {	"A":69,
		"B":70,
		"C":71,
		"D":68,
		"E":67,
		"F":13,
		"↑":64,
		"↓":25,
		"←":7,
		"→":9,
		"Setting":21,
		"R0":22,
		"R1":12,
		"R2":24,
		"R3":94,
		"R4":8,
		"R5":28,
		"R6":90,
		"R7":66,
		"R8":82,
		"R9":74};
	var axis = {
		'X-Axis':1,
		'Y-Axis':2,
		'Z-Axis':3
	}
    var inputs = {
        slider: 0,
        light: 0,
        sound: 0,
        button: 0,
        'resistance-A': 0,
        'resistance-B': 0,
        'resistance-C': 0,
        'resistance-D': 0
    };
	var values = {};
	var indexs = [];
	var startTimer = 0;
	var versionIndex = 0xFA;
	var responsePreprocessor = {};
	
    ext.resetAll = function(){
    	device.send([0xff, 0x55, 2, 0, 4]);
    };
	
	ext.runArduinoSimple = function(){
		responseValue();
	};
	
	ext.runBotSimple = function(direction,speed) {
		var leftSpeed = 0;
		var rightSpeed = 0;
		if(direction=="run_FORWARD"){
			leftSpeed = -speed;
			rightSpeed = speed;
		}else if(direction=="run_BACKWARD"){
			leftSpeed = speed;
			rightSpeed = -speed;
		}else if(direction=="turn_LEFT"){
			leftSpeed = speed;
			rightSpeed = speed;
		}else if(direction=="turn_RIGHT"){
			leftSpeed = -speed;
			rightSpeed = -speed;
		}
        if (leftSpeed>255) {leftSpeed=255} else if (leftSpeed<-255) {leftSpeed=-255}
        if (rightSpeed>255) {rightSpeed=255} else if (rightSpeed<-255) {rightSpeed=-255}
        runPackage(5,short2array(leftSpeed),short2array(rightSpeed));
    };
    
	ext.runBothMotorsSimple = function(leftMotorSpeed,rightMotorSpeed) {
		var s1 = -leftMotorSpeed;
		var s2 = rightMotorSpeed;
        if (s1>255) {s1=255} else if (s1<-255) {s1=-255}
        if (s2>255) {s2=255} else if (s2<-255) {s2=-255}
        runPackage(5,short2array(s1),short2array(s2));
    };
    
	ext.runMotorSimple = function(port,speed) {
		if(typeof port=="string"){
			port = ports[port];
		}
		if(port == 9){speed = -speed;}
		if (speed>255) {speed=255;} else if (speed<-255) {speed=-255;}
        runPackage(10,port,short2array(speed));
    };
	
	ext.stopMotorOrBothSimple = function(whichMotors) {
		var wM = whichMotors;
		var brakeStyle = 0;
		var s = 0;
		if (wM=="A_and_B") {
			wM = 255;
		} else if (typeof wM=="string") {
			wM = ports[wM];
		}
		if (wM==255) {
			runPackage(5,short2array(s),short2array(s));
		} else {
			runPackage(10,wM,short2array(s));
		}
	};
    
    ext.runServoSimple = function(port,angle) {
		var jck = 3;
		var slt = 1;
		if(typeof port=="string"){
			port = ports[port];
		}
		if(angle < 0){
			angle = 0;
		}
		if(angle > 180){
			angle = 180;
		}
		if(port==16){jck=3;slt=1;}
		else if(port==14){jck=4;slt=1;}
		else if(port==11){jck=1;slt=1;}
		else if(port==9){jck=2;slt=1;}
		else if(port==12){jck=1;slt=2;}
		else if(port==10){jck=2;slt=2;}
		else if(port==17){jck=3;slt=2;}
		else if(port==15){jck=4;slt=2;}
		runPackage(11,jck,slt,angle);
    };
	
	ext.runBuzzerSimple = function(tone, beat){
		if(typeof tone == "string"){
			tone = tones[tone];
		}
		if(typeof beat == "string"){
			beat = parseInt(beat) || beats[beat];
		}
		runPackage(34,short2array(tone), short2array(beat));
	};
	
	ext.runLedSimple = function(ledIndex,red,green,blue){
		if(ledIndex == "first_LED"){
			ledIndex = 1;
		}else if(ledIndex == "second_LED"){
			ledIndex = 2;
		}
		ext.runLedStripSimple(7, 2, ledIndex, red,green,blue);
	};
	
	ext.runLedStripSimple = function(port,slot,ledIndex,red,green,blue){
		if(typeof port=="string"){
			port = ports[port];
		}
		if("_ALL_" == ledIndex){
			ledIndex = 0;
		}
		if(typeof slot=="string"){
			slot = slots[slot];
		}
		if(port == 7 && ledIndex > 2){
			interruptThread("mCore not support led index greater than 2");
			return;
		}
		runPackage(8,port,slot,ledIndex,red,green,blue);
	};
	
	ext.resetTimerSimple = function(){
		startTimer = (new Date().getTime())/1000.0;
		responseValue();
	};
	
	ext.getButtonOnBoardSimple = function(nextID,status){
		var deviceId = 35;
		if(typeof status == "string"){
			if(status=="PRESSED"){
				status = 0;
			}else if(status=="released"){
				status = 1;
			}
		}
		getPackage(nextID,deviceId,7,status);
	};
	
	ext.getLightSensorSimple = function(nextID) {
		var deviceId = 31;
		getPackage(nextID,deviceId,6);
    };

	ext.getUltrasonicSimple = function(nextID,port){
		var deviceId = 1;
		if(typeof port=="string"){
			port = ports[port];
		}
		getPackage(nextID,deviceId,port);
	};

	ext.getStandardUltrasonicSimple = function(nextID,trig,echo){
		var deviceId = 36;
		getPackage(nextID,deviceId,trig,echo);
	}
	
	ext.getLinefollowerSimple = function(nextID,port) {
		var deviceId = 17;
		if(typeof port=="string"){
			port = ports[port];
		}
		getPackage(nextID,deviceId,port);
    };
	
	ext.getDigitalStatusSimple = function(nextID, port) {
		var deviceId = 30;
		if(typeof port=="string"){
			port = ports[port];
		}
		getPackage(nextID,deviceId,port);
    };
	
	ext.getAnalogStatusSimple = function(nextID, port) {
		var deviceId = 31;
		if(typeof port=="string"){
			port = ports[port];
		}
		getPackage(nextID,deviceId,port-14);
    };
	
	ext.setDigitalStatusSimple = function(jck,stt) {
		if(typeof jck=="string"){
			jck = ports[jck];
		}
		if(typeof stt == "string"){
			if(stt=="HIGH"){
				stt = 1;
			}else{
				stt = 0;
			}
		}
        runPackage(30,jck,stt);
    };
	
	ext.setAnalogStatusSimple = function(jck,stt) {
		if(typeof jck=="string"){
			jck = ports[jck];
		}
        runPackage(32,jck,stt);
    };
	
	ext.getTimerSimple = function(nextID){
		if(startTimer==0){
			startTimer = (new Date().getTime())/1000.0;
		}
		responseValue(nextID,(new Date().getTime())/1000.0-startTimer);
	};
	
	function sendPackage(argList, type){
		var bytes = [0xff, 0x55, 0, 0, type];
		for(var i=0;i<argList.length;++i){
			var val = argList[i];
			if(val.constructor == "[class Array]"){
				bytes = bytes.concat(val);
			}else{
				bytes.push(val);
			}
		}
		bytes[2] = bytes.length - 3;
		device.send(bytes);
	}
	
	function runPackage(){
		sendPackage(arguments, 2);
	}
	function getPackage(){
		var nextID = arguments[0];
		Array.prototype.shift.call(arguments);
		sendPackage(arguments, 1);
	}

    var inputArray = [];
	var _isParseStart = false;
	var _isParseStartIndex = 0;
    function processData(bytes) {
		var len = bytes.length;
		if(_rxBuf.length>30){
			_rxBuf = [];
		}
		for(var index=0;index<bytes.length;index++){
			var c = bytes[index];
			_rxBuf.push(c);
			if(_rxBuf.length>=2){
				if(_rxBuf[_rxBuf.length-1]==0x55 && _rxBuf[_rxBuf.length-2]==0xff){
					_isParseStart = true;
					_isParseStartIndex = _rxBuf.length-2;
				}
				if(_rxBuf[_rxBuf.length-1]==0xa && _rxBuf[_rxBuf.length-2]==0xd&&_isParseStart){
					_isParseStart = false;
					
					var position = _isParseStartIndex+2;
					var extId = _rxBuf[position];
					position++;
					var type = _rxBuf[position];
					position++;
					//1 byte 2 float 3 short 4 len+string 5 double
					var value;
					switch(type){
						case 1:{
							value = _rxBuf[position];
							position++;
						}
							break;
						case 2:{
							value = readFloat(_rxBuf,position);
							position+=4;
						}
							break;
						case 3:{
							value = readInt(_rxBuf,position,2);
							position+=2;
						}
							break;
						case 4:{
							var l = _rxBuf[position];
							position++;
							value = readString(_rxBuf,position,l);
						}
							break;
						case 5:{
							value = readDouble(_rxBuf,position);
							position+=4;
						}
							break;
						case 6:
							value = readInt(_rxBuf,position,4);
							position+=4;
							break;
					}
					if(type<=6){
						if (responsePreprocessor[extId] && responsePreprocessor[extId] != null) {
							value = responsePreprocessor[extId](value);
							responsePreprocessor[extId] = null;
						}
						responseValue(extId,value);
					}else{
						responseValue();
					}
					_rxBuf = [];
				}
			} 
		}
    }
	function readFloat(arr,position){
		var f= [arr[position],arr[position+1],arr[position+2],arr[position+3]];
		return parseFloat(f);
	}
	function readInt(arr,position,count){
		var result = 0;
		for(var i=0; i<count; ++i){
			result |= arr[position+i] << (i << 3);
		}
		return result;
	}
	function readDouble(arr,position){
		return readFloat(arr,position);
	}
	function readString(arr,position,len){
		var value = "";
		for(var ii=0;ii<len;ii++){
			value += String.fromCharCode(_rxBuf[ii+position]);
		}
		return value;
	}
    function appendBuffer( buffer1, buffer2 ) {
        return buffer1.concat( buffer2 );
    }

    // Extension API interactions
    var potentialDevices = [];
    ext._deviceConnected = function(dev) {
        potentialDevices.push(dev);
        if (!device) {
            tryNextDevice();
        }
    }

    function tryNextDevice() {
        // If potentialDevices is empty, device will be undefined.
        // That will get us back here next time a device is connected.
        device = potentialDevices.shift();
        if (device) {
            device.open({ stopBits: 0, bitRate: 115200, ctsFlowControl: 0 }, deviceOpened);
        }
    }

    var watchdog = null;
    function deviceOpened(dev) {
        if (!dev) {
            // Opening the port failed.
            tryNextDevice();
            return;
        }
        device.set_receive_handler('simpleBot',processData);
    };

    ext._deviceRemoved = function(dev) {
        if(device != dev) return;
        device = null;
    };

    ext._shutdown = function() {
        if(device) device.close();
        device = null;
    };

    ext._getStatus = function() {
        if(!device) return {status: 1, msg: 'simpleBot disconnected'};
        if(watchdog) return {status: 1, msg: 'Probing for simpleBot'};
        return {status: 2, msg: 'simpleBot connected'};
    }
    var descriptor = {};
	ScratchExtensions.register('simpleBot', descriptor, ext, {type: 'serial'});
})({});

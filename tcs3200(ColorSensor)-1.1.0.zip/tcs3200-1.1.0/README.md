# TCS3200 color sensor library

TCS200 color sensor library for Arduino

## Wiring schematics


![Schematics for wiring TCS3200 sensor to Arduino UNO](https://github.com/Panjkrc/TCS3200_library/blob/master/wiring_schematics.png)

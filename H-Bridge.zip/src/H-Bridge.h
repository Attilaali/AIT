#include <Arduino.h>
#define HBRIDGENUMOFMOTORS 10
// version 1.2

byte motorHBridge[][4] = {
  {0,0,0,0},
  {0,0,0,0},
  {0,0,0,0},
  {0,0,0,0},
  {0,0,0,0},
  {0,0,0,0},
  {0,0,0,0},
  {0,0,0,0},
  {0,0,0,0},
  {0,0,0,0},
  {0,0,0,0}
};

// MEMORANDUM: mot[idx][0] - type of driver; mot[idx][1] - pin1; mot[idx][2] - pin2; mot[idx][3] - option
// "speed": 32767 - unattach (type of driver = 0),
// 32766 - release (INPUT), 32765 - init (OUTPUT), 32764 - stop (brake), 32763 - stop (free)
 
void setOrRunHBridgeMotor(byte idx, int spd) {
  byte dType,pin1,pin2,opt;
  dType=motorHBridge[idx][0]; 
  pin1=motorHBridge[idx][1]; 
  pin2=motorHBridge[idx][2]; 
  opt=motorHBridge[idx][3];
  int absSpd=abs(spd);
  if ((pin1>1)&&(pin2>1)) {
    switch (dType) {
      case 1:
        // Orion-like
        if (absSpd < 256) {
           if (boolean(opt)) {spd=-spd;};
           digitalWrite(pin1,spd>=0);
           analogWrite(pin2,absSpd);        
        } else if (absSpd<32765) {
           digitalWrite(pin1,LOW); digitalWrite(pin2,LOW); // brake
        } else if (absSpd==32765) {
           pinMode(pin1,OUTPUT); pinMode(pin2,OUTPUT); // init motor
        } else if (absSpd==32766) {
           pinMode(pin1,INPUT); pinMode(pin2,INPUT); // release motor
        } else if (absSpd>32766) {
           motorHBridge[idx][0]=0; // unattach
           digitalWrite(pin1,LOW); digitalWrite(pin2,LOW);
           pinMode(pin1,INPUT); pinMode(pin2,INPUT);
        }
        break;
      case 2:
        // Auriga-like
        if (opt>1) {
           if (absSpd < 256) {
              digitalWrite(pin1,spd>=0);
              digitalWrite(pin2,spd<=0);
              analogWrite(opt,absSpd);
           } else if (absSpd<32764) {
              digitalWrite(pin1,LOW); digitalWrite(pin2,LOW); digitalWrite(opt,LOW); // soft brake
           } else if (absSpd==32764) {
              digitalWrite(pin1,HIGH); digitalWrite(pin2,HIGH); digitalWrite(opt,LOW); // hard brake
           } else if (absSpd==32765) {
              pinMode(pin1,OUTPUT); pinMode(pin2,OUTPUT); pinMode(opt,OUTPUT); // init motor
           } else if (absSpd==32766) {
              pinMode(pin1,INPUT); pinMode(pin2,INPUT); pinMode(opt,INPUT); // release motor
           } else if (absSpd>32766) {
              motorHBridge[idx][0]=0; // unattach
              digitalWrite(pin1,LOW); digitalWrite(pin2,LOW); digitalWrite(opt,LOW);
              pinMode(pin1,INPUT); pinMode(pin2,INPUT); pinMode(opt,INPUT);
           }
        }
        break;
      case 3:
        // HG7881-like
        if (absSpd > 32766) {
            motorHBridge[idx][0]=0; // unattach
            digitalWrite(pin1,LOW); digitalWrite(pin2,LOW);
            pinMode(pin1,INPUT); pinMode(pin2,INPUT);
        } else if (absSpd == 32766) {
            pinMode(pin1,INPUT); pinMode(pin2,INPUT); // release motor
        } else if (absSpd == 32765) {
            pinMode(pin1,OUTPUT); pinMode(pin2,OUTPUT); // init motor
        } else if (absSpd == 32764) {
            digitalWrite(pin1,HIGH); digitalWrite(pin2,HIGH); // HARD BRAKE			
        } else if (absSpd>255) {
            digitalWrite(pin1,LOW); digitalWrite(pin2,LOW); // soft brake
        } else if (opt < 4) {
            if ((opt == 0) || (spd==0) || ((opt==1)&&(spd>0)) || ((opt==2)&&(spd<0))) {
                if (spd==0) {
                  digitalWrite(pin1,HIGH); digitalWrite(pin2,HIGH);
                } else {
                  analogWrite(pin1,constrain(-spd,0,255));
                  analogWrite(pin2,constrain(spd,0,255));
                }
            } else if (spd<0) {
                  digitalWrite(pin1,HIGH);
                  analogWrite(pin2,255+constrain(spd,-255,0));
            } else {
                  digitalWrite(pin2,HIGH);
                  analogWrite(pin1,255-constrain(spd,0,255));
            }
        }
        break;
    }
  }
}

void runHBridgeMotor(byte idx, int spd) {
	setOrRunHBridgeMotor(idx,constrain(spd,-255,255));
}

void moveHBridgeRobot(byte dir, int spd) {
	int leftSpeed, rightSpeed;
	if (dir==1) {
		leftSpeed=spd;
		rightSpeed=spd;
	} else if (dir==2) {
		leftSpeed=-spd;
		rightSpeed=-spd;
	} else if (dir==3) {
		leftSpeed=-spd;
		rightSpeed=spd;
	} else if (dir==4) {
		leftSpeed=spd;
		rightSpeed=-spd;
	}
	runHBridgeMotor(9,leftSpeed);
	runHBridgeMotor(10,rightSpeed);
}

void runBothHBridgeMotors(int leftSpeed, int rightSpeed) {
	runHBridgeMotor(9,leftSpeed);
	runHBridgeMotor(10,rightSpeed);
}

void freeHBridgeMotor(byte idx) {
	setOrRunHBridgeMotor(idx,32763);
}

void brakeHBridgeMotor(byte idx) {
	setOrRunHBridgeMotor(idx,32764);
}

void initHBridgeMotor(byte idx) {
	setOrRunHBridgeMotor(idx,32765);
}

void releaseHBridgeMotor(byte idx) {
	setOrRunHBridgeMotor(idx,32766);
}

void unattachHBridgeMotor(byte idx) {
	setOrRunHBridgeMotor(idx,32767);
}

// MEMORANDUM: mot[idx][0] - type of driver; mot[idx][1] - pin1; mot[idx][2] - pin2; mot[idx][3] - option
// "speed": 32767 - unattach (type of driver = 0),
// 32766 - release (INPUT), 32765 - init (OUTPUT), 32764 - stop (brake), 32763 - stop (free)
 

void configureHBridgeMotor(byte idx, byte dType, byte pin1, byte pin2, byte opt) {
  motorHBridge[idx][0]=dType; 
  motorHBridge[idx][1]=pin1; 
  motorHBridge[idx][2]=pin2; 
  motorHBridge[idx][3]=opt;
}

void configureBothHBridgeMotorsDefultSettings(byte dType) {
	if (dType==1) {
		configureHBridgeMotor(9,1,7,6,1);
		configureHBridgeMotor(10,1,4,5,0);
	} else if (dType==2) {
		configureHBridgeMotor(9,2,47,46,10);
		configureHBridgeMotor(10,2,48,49,11);
	} else if (dType==3) {
		configureHBridgeMotor(9,3,3,9,0);
		configureHBridgeMotor(10,3,10,11,0);
	}
  initHBridgeMotor(9);
  initHBridgeMotor(10);
}

void stopHBridgeMotorOrBoth(int mode, byte idx) {
	if (idx==255) {
		setOrRunHBridgeMotor(9,mode);
		setOrRunHBridgeMotor(10,mode);
	} else {
		setOrRunHBridgeMotor(idx,mode);
	}
}
